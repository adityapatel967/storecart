const products = [
  { id: 1, name: "Wireless Headphones", price: 1999, image: "https://via.placeholder.com/250x200" },
  { id: 2, name: "Smart Watch", price: 2499, image: "https://via.placeholder.com/250x200" },
  { id: 3, name: "Bluetooth Speaker", price: 1299, image: "https://via.placeholder.com/250x200" }
];

let cart = [];

function renderProducts() {
  const productList = document.getElementById("product-list");
  productList.innerHTML = "";
  products.forEach(product => {
    const card = document.createElement("div");
    card.className = "product-card";
    card.innerHTML = `
      <img src="\${product.image}" alt="\${product.name}" />
      <h3>\${product.name}</h3>
      <p>Price: ₹\${product.price}</p>
      <button onclick="addToCart(\${product.id})">Add to Cart</button>
    `;
    productList.appendChild(card);
  });
}

function addToCart(productId) {
  const product = products.find(p => p.id === productId);
  cart.push(product);
  document.getElementById("cart-count").innerText = cart.length;
  renderCartItems();
}

function renderCartItems() {
  const cartList = document.getElementById("cart-items");
  cartList.innerHTML = "";
  cart.forEach(item => {
    const li = document.createElement("li");
    li.innerText = `\${item.name} - ₹\${item.price}`;
    cartList.appendChild(li);
  });
}

function openCart() {
  document.getElementById("cart-modal").classList.remove("hidden");
}

function closeCart() {
  document.getElementById("cart-modal").classList.add("hidden");
}

function openAuthModal() {
  document.getElementById("auth-modal").classList.remove("hidden");
}
function closeAuthModal() {
  document.getElementById("auth-modal").classList.add("hidden");
}

function registerUser() {
  const username = document.getElementById("auth-username").value;
  const password = document.getElementById("auth-password").value;

  if (!username || !password) {
    showMessage("Please enter both fields.");
    return;
  }

  const users = JSON.parse(localStorage.getItem("users")) || [];
  if (users.find(u => u.username === username)) {
    showMessage("User already exists.");
    return;
  }

  users.push({ username, password });
  localStorage.setItem("users", JSON.stringify(users));
  showMessage("Registered successfully. Now login.");
}

function loginUser() {
  const username = document.getElementById("auth-username").value;
  const password = document.getElementById("auth-password").value;

  const users = JSON.parse(localStorage.getItem("users")) || [];
  const user = users.find(u => u.username === username && u.password === password);

  if (user) {
    localStorage.setItem("loggedInUser", username);
    updateUserArea();
    closeAuthModal();
  } else {
    showMessage("Invalid credentials.");
  }
}

function logoutUser() {
  localStorage.removeItem("loggedInUser");
  updateUserArea();
}

function updateUserArea() {
  const username = localStorage.getItem("loggedInUser");
  const userArea = document.getElementById("user-area");

  if (username) {
    userArea.innerHTML = `👤 Hello, \${username} <button onclick="logoutUser()">Logout</button>`;
  }
}

function showMessage(msg) {
  document.getElementById("auth-message").innerText = msg;
}

document.getElementById("cart").addEventListener("click", openCart);
renderProducts();
updateUserArea();
